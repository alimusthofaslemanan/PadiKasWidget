package com.padikas.widget

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.color.ColorProvider
import androidx.glance.layout.*
import androidx.glance.text.*
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.unit.*

class PadiKasWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) = provideContent { Content(context) }

    @Composable private fun Content(context: Context) {
        val green = ColorProvider(android.graphics.Color.rgb(11,107,79))
        Column(GlanceModifier.fillMaxSize().background(ColorProvider(android.graphics.Color.WHITE)).padding(14.dp)) {
            Row(GlanceModifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(GlanceModifier.defaultWeight()) {
                    Text("🌾 PadiKas", style = TextStyle(color = green, fontSize = 21.sp, fontWeight = FontWeight.Bold))
                    Text("Kondisi Sawah Anda", style = TextStyle(color = ColorProvider(android.graphics.Color.DKGRAY), fontSize = 13.sp))
                }
                Text("● Aktif", style = TextStyle(color = green, fontSize = 13.sp, fontWeight = FontWeight.Bold))
            }
            Spacer(GlanceModifier.height(12.dp))
            Text("Padi  •  HST 42", style = TextStyle(color = green, fontSize = 22.sp, fontWeight = FontWeight.Bold))
            Text("Fase: Pembentukan Malai", style = TextStyle(color = ColorProvider(android.graphics.Color.DKGRAY), fontSize = 14.sp))
            Spacer(GlanceModifier.height(10.dp))
            Row(GlanceModifier.fillMaxWidth()) {
                Info("🌤️ 28°C", "Mendung")
                Spacer(GlanceModifier.width(10.dp))
                Info("🌧️ 70%", "Peluang hujan")
            }
            Spacer(GlanceModifier.height(8.dp))
            Row(GlanceModifier.fillMaxWidth()) {
                Info("💧 82%", "Kelembapan")
                Spacer(GlanceModifier.width(10.dp))
                Info("💨 8 km/j", "Angin")
            }
            Spacer(GlanceModifier.height(12.dp))
            Text("⚠️ Rekomendasi Perawatan", style = TextStyle(color = ColorProvider(android.graphics.Color.rgb(180,95,0)), fontSize = 15.sp, fontWeight = FontWeight.Bold))
            Text("Waspada hujan sore. Atur waktu pemupukan agar tidak bertepatan dengan hujan.", style = TextStyle(color = ColorProvider(android.graphics.Color.DKGRAY), fontSize = 13.sp))
            Spacer(GlanceModifier.height(12.dp))
            Button(text = "Lihat Detail di PadiKas →", onClick = actionStartActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://hitungkeuntunganpadi.lovable.app"))), modifier = GlanceModifier.fillMaxWidth())
        }
    }
    @Composable private fun Info(big: String, small: String) {
        Column(GlanceModifier.defaultWeight().background(ColorProvider(android.graphics.Color.rgb(241,248,246))).padding(8.dp)) {
            Text(big, style = TextStyle(fontSize = 17.sp, fontWeight = FontWeight.Bold))
            Text(small, style = TextStyle(fontSize = 11.sp))
        }
    }
}
