package com.padikas.widget

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://hitungkeuntunganpadi.lovable.app")))
        finish()
    }
}
